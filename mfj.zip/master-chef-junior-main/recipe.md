Once you are done with the rinsing process, it's time to fry them.
Take a medium-sized pan and add your preferred cooking oil. Heat the oil till you can see small bubbles on the side.
Now, add the sliced potatoes to the pan. Make sure you don't overcrowd the pan so that they are not stacked on top of each other.
Fry them for 5-6 minutes or until they are light golden in colour.
Take them out and allow them to cool down to normal room temperature.
Return the fries into the pan and fry them for 2-3 minutes or until crispy and dark golden brown in colour.
Place fries on paper towel to absorb excess oil, if any.
Sprinkle salt over the fries. Fries will be crispy on the outside and soft on the inside.